@extends('/baseTemp')
@section('content')

    <div class="cardHolder">
        @foreach($allCategories as $category)
        <a href="create{{$category -> id}}">
            <div class="card">
                <img src="img/{{$category -> img_path}}" alt="" srcset="" class="cardImg">
                <div class="cardDetail">
                    <p>{{$category -> cate_name}}</p>
                    <p>MVR {{$category -> unit_price}}/PER EACH</p>
                </div>
            </div>
        </a>
        @endforeach

        
    </div>
    <div class="addButton" onclick="PopUpContainer('category')">
        <h3>+ New Category</h3>
    </div>
    @if ($errors->any())
        <div id="alertMSG" class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form action="/dashboard" method="POST" enctype="multipart/form-data" id="popUpContainer">
        @csrf
        <h3>Add new Category</h3>
        <input type="text" name="cate_name" placeholder="Category Name" class="inputField">
        <input type="number" name="unit_price" placeholder="Unit Price" step="0.01" class="inputField">
        <input type="file" name="img" class="inputField"><br>
        
        <button class="CateSaveBtn" onclick="PopUpContainer('category')">
            <h3>Save</h3>
        </button>
    </form>
    <script>
        function PopUpContainer(_input){
            if(_input =="category"){
                document.getElementById('popUpContainer').style.display = 'block';
                document.getElementById('NavCloser').style.display = 'block';
            }
        }
    </script>

@endsection 