<?php

namespace App\Http\Controllers;

use App\Models\collection;
use App\Models\category;
use App\Models\customer;
use App\Models\package;
use App\Models\shipment;
use Illuminate\Http\Request;

class CollectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $AllPackage = package::orderBy('id','DESC')->get();
        return view('collect',['AllPackage'=>$AllPackage]);
    }

    public function clam(Request $request)
    {
        $load = package::where('id',$request->packid)->get();
        $laodCustomer = customer::where('id',$load[0]->customer_id)->get();
        $itemsLoaded = shipment::where('packages_id',$request->packid)->get();
        $allCategories = category::all();
        // dd($laodCustomer);
        return view('clam',['load'=>$load,'laodCustomer'=>$laodCustomer,'itemsLoaded'=>$itemsLoaded,'allCategories'=>$allCategories]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        dd($request);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\collection  $collection
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        dd($request);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\collection  $collection
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        dd($request);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\collection  $collection
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, collection $collection)
    {
        dd($request);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\collection  $collection
     * @return \Illuminate\Http\Response
     */
    public function destroy(collection $collection)
    {
        dd($request);
    }
}
