<?php

namespace App\Http\Controllers;

use App\Models\shipment;
use App\Models\category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File; 

class ShipmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(session::has('NewCustomer')){
            $allCategories = category::all();
            if(Session::has('newpackage')){
                if (shipment::where('packages_id', Session::get('newpackage')->id)->exists()){
                    $Shipments = shipment::where('packages_id', Session::get('newpackage')->id)->get();
                    return view('create',['allCategories' => $allCategories, 'Shipments'=>$Shipments]);
                    // return view('create',['allCategories' => $allCategories]);
                }else{
                    return view('create',['allCategories' => $allCategories]);

                }
            }else{

                return view('create',['allCategories' => $allCategories]);
            }
        }else{
            return redirect('/customer');
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $allCategories = category::all();
        dd($allCategories);
        return view('create',['allCategories' => $allCategories]);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($request->submit == "AddItem"){
            $this->validate($request, [
                'qty' => ['required'],
                'unit_price' => ['required'],
                'cateID' => ['required'],
                'packID' => ['required']
            ]);
            $newPath = "load_default.png";
            if(Request('img')!=null){
                $newPath = time() . "_pack_id_" . Request('packID') . "." . request('img')->extension();
                request('img')->move(public_path("item_img"), $newPath);
            }
            
            $newShipment = new shipment ([
                'qty' => Request('qty'),
                'unit_price' => Request('unit_price'),
                'img_path' => $newPath,
                'category_id' => Request('cateID'),
                'packages_id' => Request('packID')
            ]);
            $newShipment->save();
        }
        return redirect('/create');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\shipment  $shipment
     * @return \Illuminate\Http\Response
     */
    public function show(shipment $shipment)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\shipment  $shipment
     * @return \Illuminate\Http\Response
     */
    public function edit(shipment $shipment)
    {
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\shipment  $shipment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, shipment $shipment)
    {
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\shipment  $shipment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        if($request->submit == "delete"){
            $deleteItem = shipment::find($request->cateID);
            $fileName = 'item_img/'. $deleteItem->img_path;
            File::delete($fileName);
            $deleteItem->delete();
            return redirect('/create');
        }elseif($request->submit == "AddItem"){
            shipment::where('id', $request->cateID)->update([
                'qty' => Request('qty'),
                'unit_price' => Request('unit_price')
            ]);
            return redirect('/create');
        }
    }
}
