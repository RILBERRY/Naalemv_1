<?php

namespace App\Actions\Fortify;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array  $input
     * @return \App\Models\User
     */
    public function create(array $input)
    {
        Validator::make($input, [
            'uname' => ['required', 'string', 'max:255'],
            'bname' => ['required', 'string', 'max:255'],
            'email' => ['required','email', 'string', 'max:255'],
            'contact' => [
                'required',
                'integer',
                Rule::unique(User::class),
            ],
            'password' => $this->passwordRules(),
        ])->validate();

        return User::create([
            'username' => $input['uname'],
            'boatname' => $input['bname'],
            'contact' => $input['contact'],
            'email' => $input['email'],
            'password' => Hash::make($input['password']),
        ]);
    }
}
