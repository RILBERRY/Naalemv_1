<?php $__env->startSection('content'); ?>
    <h4 class="Note">Scan QR from viber</h4>
    <img src="img/ViberBotQR.png" alt="" srcset="" class="ViberBotQR">

    <a href="/customer">
        <button class="addButton SaveBtn">
            <h3>Done</h3>
        </button>
    </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/baseTemp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/NaaleMV/resources/views/confirm.blade.php ENDPATH**/ ?>