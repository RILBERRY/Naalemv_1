<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/main.css">
    <title>Naale MV - Dashboard</title>
</head>
<body>
    <div class="NavCloser" id="NavCloser" onclick="CloseNav()"></div>
    <div class="navBar" id="NavBar">
        <li id="NavL1" ><a href="/dashboard">HOME</a></li>
        <li id="NavL2"><a href="/customer">LOAD</a></li>
        <li id="NavL3"><a href="/collect">COLLECTION</a></li>
        <form action="/logout" method="POST">
        <?php echo csrf_field(); ?>
        <li id="NavL4"><button class="BtnNone" type="Submit">LOGOUT</button></li>
        </form>
    </div>
    
    <div class="MaxContainer">
        <div class="topCont">
            <div class="Logo">
                <h2>Naale MV</h2>
                <h4><?php echo e(Auth::user()->boatname); ?></h4>
            </div>
            <div class="burgerManu" onclick="OpenNav()">
                <div class="dash"></div>
                <div class="dash"></div>
                <div class="dash"></div>
            </div>
        </div>
        <h3 class="pageTitle">Dashboard</h3>
        <div class="mainContainer p10">

        <!-- Contents will be loaded hear from the database -->
        <?php echo $__env->yieldContent('content'); ?>

        <!-- end of the content -->
        </div>
    </div>
    
    <script>
        function CloseNav(){
            document.getElementById('NavBar').style.display = 'none';
            document.getElementById('NavCloser').style.display = 'none';
            document.getElementById('EditItem').style.display = 'none';
            document.getElementById('AddItem').style.display ='none';
            document.getElementById('popUpContainer').style.display = 'none';
        }
        function OpenNav(){
            document.getElementById('NavBar').style.display = 'block';
            document.getElementById('NavL2').classList.add('NavTransis');
            document.getElementById('NavCloser').style.display = 'block';
        }
        setTimeout(function(){
            document.getElementById('alertMSG').style.display = "none";
        }, 5000);
    </script>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/NaaleMV/resources/views//baseTemp.blade.php ENDPATH**/ ?>