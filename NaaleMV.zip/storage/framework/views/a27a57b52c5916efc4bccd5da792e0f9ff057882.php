<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css">
    <title>Naale MV - Portal</title>
</head>
<body>
    <div class="MaxContainer">
        <h3 class="PageTitle">Naale MV</h3>
        <div class="mainCont">
            <div class="imgCont">
                <img src="<?php echo e(asset('img/BG-IMG-LOGIN.png')); ?>" alt="" srcset="">
            </div>
            <?php if($errors->any()): ?>
                <div id="alertMSG" class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="loginForm">
                <form class="loginFormCont" action="/login" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="number" name="contact" placeholder="Mobile Number" class="inputField">
                    <input type="password" name="password" placeholder="Password" class="inputField">
                    <button type="submit" class="FormBtn">LOGIN</button>
                </form>
            </div>
        </div>
    </div>
    <script>
        setTimeout(function(){
            document.getElementById('alertMSG').style.display = "none";
        }, 5000);
    </script>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/NaaleMV/resources/views/index.blade.php ENDPATH**/ ?>