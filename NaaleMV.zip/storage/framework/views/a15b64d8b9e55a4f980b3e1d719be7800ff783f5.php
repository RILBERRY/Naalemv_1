<?php $__env->startSection('content'); ?>

    <div class="cardHolder">
        <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="create<?php echo e($category -> id); ?>">
            <div class="card">
                <img src="img/<?php echo e($category -> img_path); ?>" alt="" srcset="" class="cardImg">
                <div class="cardDetail">
                    <p><?php echo e($category -> cate_name); ?></p>
                    <p>MVR <?php echo e($category -> unit_price); ?>/PER EACH</p>
                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </div>
    <div class="addButton" onclick="PopUpContainer('category')">
        <h3>+ New Category</h3>
    </div>
    <?php if($errors->any()): ?>
        <div id="alertMSG" class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="/dashboard" method="POST" enctype="multipart/form-data" id="popUpContainer">
        <?php echo csrf_field(); ?>
        <h3>Add new Category</h3>
        <input type="text" name="cate_name" placeholder="Category Name" class="inputField">
        <input type="number" name="unit_price" placeholder="Unit Price" step="0.01" class="inputField">
        <input type="file" name="img" class="inputField"><br>
        
        <button class="CateSaveBtn" onclick="PopUpContainer('category')">
            <h3>Save</h3>
        </button>
    </form>
    <script>
        function PopUpContainer(_input){
            if(_input =="category"){
                document.getElementById('popUpContainer').style.display = 'block';
                document.getElementById('NavCloser').style.display = 'block';
            }
        }
    </script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('/baseTemp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/NaaleMV/resources/views/dashboard.blade.php ENDPATH**/ ?>