<?php $__env->startSection('content'); ?>

    <div class="search">
        <input  type="text" name="" placeholder="Search By number, house name, load no" class="inputField inputSmall ">
    </div>
    <div class="ContContainer">
        <h4 class="TitleHeading">----------- un clamed items ----------- </h4>
        <?php $__currentLoopData = $AllPackage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_AllPackage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($_AllPackage->status != "COLLECTED"): ?>
        <a class="textDecod"href="clam?packid=<?php echo e($_AllPackage->id); ?>">
            <div class="ItemCont">
                <h4 class="LoadNo"><strong>Package : </strong> MG-2021-<?php echo e($_AllPackage->id); ?></h4>
                <h4 class="ItemDes" ><strong>House name:</strong> <?php echo e($_AllPackage->CustAddress); ?> </h4>
            </div>
        </a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>

    <div class="ContContainer">
        <h4 class="TitleHeading">------------ clamed items ------------ </h4>
        <?php $__currentLoopData = $AllPackage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_AllPackage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($_AllPackage->status == "COLLECTED"): ?>
        <a class="textDecod"href="clam/<?php echo e($_AllPackage->id); ?>">
            <div class="ItemCont">
                <h4 class="LoadNo"><strong>Load : </strong> MG-2021-<?php echo e($_AllPackage->id); ?></h4>
                <h4 class="ItemDes" ><strong>House name:</strong> <?php echo e($_AllPackage->CustAddress); ?> </h4>
            </div>
        </a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('/baseTemp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/NaaleMV/resources/views/collect.blade.php ENDPATH**/ ?>