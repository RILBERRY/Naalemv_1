*************README*************
DOWNLOADED FROM www.arushad.org
--------------------------------
http://arushad.org/list-of-all-the-islands-of-the-maldives

Beware that some few islands might be missing and there may be some slight errors.
If you do find any errors please let me know via email to contact@arushad.org

The atoll data are arranged with the columns:
atoll registration number,
English atoll name abbreviation,
Dhivehi atoll name abbreviation,
English latin atoll name abbreviation,
official atoll name in latin,
official atoll name in Thaana.

The islands data are arranged with the columns;
isles.egov.mv id,
atoll registration number,
island registration number (for inhabited islands only),
island name in latin, island name in thaana,
island type, resort name in english (only for resort islands),
resort name in thaana (only for resort islands),
longitude (in decimal),
latitude (in decimal).

Both the files are tab delimited text files and can be imported into any spreadsheet or database program.